 const openBtn = document.getElementById("openHTML"); // Open HTML Lesson
      const closeBtn = document.getElementById("closeHTML"); // Close HTML Lesson
      const HTMLBox = document.getElementById("HTMLBox"); // Lessons container

      // Open Lesson box when "Learn More" is clicked
      openBtn.addEventListener("click", () => {
        HTMLBox.classList.add("open");
      });

      // Close Lesson box when "Close" button is clicked
      closeBtn.addEventListener("click", () => {
        HTMLBox.classList.remove("open");
      });

      // Close Lesson box when clicking outside the inner box
      HTMLBox.addEventListener("click", (e) => {
        if (e.target === HTMLBox) HTMLBox.classList.remove("open");
      });